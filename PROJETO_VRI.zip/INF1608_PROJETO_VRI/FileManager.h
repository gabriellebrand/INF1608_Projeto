unsigned char * FM_readScanFile (char * path, size_t fileSize);

void FM_writePGMFile(double * values, int width, int height);